Projede bir hayvan barınağının işleyişine çözüm üretilecektir.
Projede hayvanların türlerine göre kayıt işlemleri yapılabilecek,
hayvanların sahiplenme için tanıtımı yapılacak ve üyeler tarafından
sahiplenme işlemi yapılabilecektir.
Projede iki rol olacaktır; Admin ve Üye.
Admin rolü bütün ekleme,silme,güncelleme yetkisine sahip olacaktır.
Üye rolü ise sahiplenme işlemini yapabilecektir.
Kimliği doğrulanmamış kullanıcılar tüm içeriğe ulaşabilecek ancak
sahiplenme işlemi için istek gönderdiğinde ilk önce login sayfasına yönlendirilecek
eğer hesabı yoksa oradan register sayfasına yönlendirilecektir.  
Proje Grubu:
1.b191210049 Emre Harman
2.b181210378 Furkan Şengül
3.g171210105 Mustafa Celal Güler
